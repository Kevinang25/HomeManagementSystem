/********************************************
*			STM32F439 Main (C Header File)  			*
*			Developed for the STM32								*
*			Author: Dr. Glenn Matthews						*
*			Header File														*
********************************************/


// Compiler pragmas
#pragma diag_warning 1						// Disable warning:  #1-D: last line of file ends without a newline



